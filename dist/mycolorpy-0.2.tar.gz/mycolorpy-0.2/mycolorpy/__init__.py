import matplotlib.pyplot as plt 
import matplotlib.colors as colors
import numpy as np